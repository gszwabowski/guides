#! /bin/csh
#SBATCH --ntasks=4
#SBATCH --partition=computeq
#SBATCH --job-name=ph4_search


/public/apps/moe/moe2018/bin/moebatch -load ../batch_ph4search.svl \
-exec "random_ph4search ['../compound_db.mdb', 'A2A', 3, 29, 569]"

