#! /bin/csh
#SBATCH --ntasks=4
#SBATCH --partition=computeq
#SBATCH --job-name=ligand_confsearch

/public/apps/moe/moe2018/bin/moebatch -exec "ConfSearch [infile: 'ligands.mdb', outfile: 'ligands_confsearch.mdb', method: 'Stochastic', dbview: 0, maxconf: 10, invert_sp3: 1]"
